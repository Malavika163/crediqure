import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class EditProfileScreen extends StatefulWidget {
  final String vinid; // Receiving user ID

  const EditProfileScreen({super.key, required this.vinid});

  @override
  _EditProfileScreenState createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  TextEditingController mobileController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController addressController = TextEditingController();

  bool isLoading = true; // Show loader initially
  String errorMessage = ""; // Store error messages

  @override
  void initState() {
    super.initState();
    fetchUserData();
  }

  // Fetch user details using GET request
  Future<void> fetchUserData() async {
    try {
      // Pass loginid as a query parameter instead of body
      var response = await http.get(
        Uri.parse("https://www.crediqure.com/appdevelopment/malavika/get_user.php?loginid=${widget.vinid}"),
      );

      print("GET User API Status: ${response.statusCode}");
      print("GET User API Response: ${response.body}");

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);

        if (data['success'] == "true") {
          setState(() {
            mobileController.text = data['mobile'] ?? "";
            emailController.text = data['email'] ?? "";
            addressController.text = data['address'] ?? "";
            isLoading = false;
          });
        } else {
          setState(() {
            errorMessage = data['message'] ?? "Failed to load user data";
            isLoading = false;
          });
        }
      } else {
        setState(() {
          errorMessage = "Server Error: ${response.statusCode}";
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = "Network error: $e";
        isLoading = false;
      });
    }
  }

  // Update profile API call
  Future<void> updateProfile() async {
    try {
      var response = await http.post(
        Uri.parse("https://www.crediqure.com/appdevelopment/malavika/update_profile.php"),
        body: {
          'loginid': widget.vinid, // Ensure correct key
          'mobile': mobileController.text,
          'email': emailController.text,
          'address': addressController.text,
        },
      );

      print("Update API Response: ${response.body}");

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);

        if (data['success'] == "true") {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Profile Updated Successfully!')),
          );
        } else {
          setState(() {
            errorMessage = data['message'] ?? "Profile update failed!";
          });
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error: ${data['message']}')),
          );
        }
      } else {
        setState(() {
          errorMessage = "Server Error: ${response.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = "Network error: $e";
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        backgroundColor: const Color.fromARGB(255, 100, 1, 1),
        title: const Text("Edit Profile", style: TextStyle(color: Colors.white)),
        centerTitle: true,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator()) // Show loader while fetching data
          : Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Center(
                    child: Image.asset('assets/logo.png', height: 100), // App logo
                  ),
                  const SizedBox(height: 20),

                  // Display User ID
                  Text("User ID: ${widget.vinid}",
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),

                  const SizedBox(height: 20),

                  // Input Fields
                  buildTextField("Mobile Number", Icons.phone, mobileController),
                  const SizedBox(height: 15),

                  buildTextField("Email", Icons.email, emailController),
                  const SizedBox(height: 15),

                  buildTextField("Address", Icons.location_on, addressController),
                  const SizedBox(height: 30),

                  // Show error message if API fails
                  if (errorMessage.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Text(
                        errorMessage,
                        style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                      ),
                    ),

                  // Update Profile Button
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color.fromARGB(255, 100, 1, 1),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      onPressed: updateProfile,
                      child: const Text(
                        'Update Profile',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  // Reusable TextField Widget
  Widget buildTextField(String label, IconData icon, TextEditingController controller) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: const Color.fromARGB(255, 100, 1, 1)),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }
}
