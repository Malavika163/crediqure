// import 'package:crediqure/dashboard.dart';
// import 'package:flutter/material.dart';

// class LoginSuccessScreen extends StatelessWidget {
  

//   const LoginSuccessScreen({super.key, });

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
     
//       body: Center(
//         child: Padding(
//           padding: const EdgeInsets.all(16.0),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               Icon(
//                 Icons.check_circle_outline,
//                 color: Color.fromARGB(255, 157, 246, 160),
//                 size: 100,
//               ),
//               const SizedBox(height: 20),
//               Text(
//                 "Welcome, User",
//                 style: TextStyle(
//                   fontSize: 24,
//                   fontWeight: FontWeight.bold,
//                   color: Colors.black87,
//                 ),
//               ),
//               const SizedBox(height: 10),
//               const Text(
//                 "You have successfully logged in.",
//                 style: TextStyle(
//                   fontSize: 16,
//                   color: Colors.grey,
//                 ),
//                 textAlign: TextAlign.center,
//               ),
//               const SizedBox(height: 30),
//               ElevatedButton(
//                 onPressed: () {
//                   Navigator.pushReplacement(
//                       context,
//                       //MaterialPageRoute(
//                          // builder: (context) =>  DashboardScreen(this.vinid)));
//                 },
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor:Color.fromARGB(255, 157, 246, 160),
//                 ),
//                 child: const Text("Go to Dashboard"),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }

