import 'package:flutter/material.dart';

class login_record extends StatefulWidget {
  const login_record({super.key});

  @override
  State<login_record> createState() => _LoginRecordState();
}

class _LoginRecordState extends State<login_record> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}