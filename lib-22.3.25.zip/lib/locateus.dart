import 'package:crediqure/googlemap.dart';
import 'package:flutter/material.dart';

class LocateUsPage extends StatelessWidget {
  const LocateUsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
         leading: IconButton(
    icon: Icon(Icons.arrow_back),
    onPressed: () {
      Navigator.pop(context); // This will navigate back
    },
  ),
        title: Text('Locate Us',style: TextStyle(color:Colors.white),),
        backgroundColor: Color(0xff800000),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildLocationCard(
              title: "🏢 Head Office - Kodungalore",
              address: "Crediqure Gold Loan Services,\nKodungalore, Kerala, India",
              phone: "+91 XXXXXXXXXX",
              email: "support@crediqure.com",
              onMapPressed: () {
                   Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => ViewMapPage()));
              },
            ),
            _buildLocationCard(
              title: "🏦 Branch - Thrissur",
              address: "Crediqure Gold Loan Branch,\nThrissur, Kerala, India",
              phone: "+91 XXXXXXXXXX",
              email: "thrissur@crediqure.com",
              onMapPressed: () {
                 Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => ViewMapPage()));
              }
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLocationCard({
    required String title,
    required String address,
    required String phone,
    required String email,
    required VoidCallback onMapPressed,
  }) {
    return Card(
      margin: EdgeInsets.all(12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 5,
      child: Padding(
        padding: EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 5),
            Text(address, style: TextStyle(fontSize: 14, color: Colors.black54)),
            SizedBox(height: 10),
            Row(
              children: [
                Icon(Icons.phone, color:Color(0xff800000), size: 18),
                SizedBox(width: 5),
                Text(phone, style: TextStyle(fontSize: 14)),
              ],
            ),
            Row(
              children: [
                Icon(Icons.email, color:Color(0xff800000), size: 18),
                SizedBox(width: 5),
                Text(email, style: TextStyle(fontSize: 14)),
              ],
            ),
            _buildViewMapButton(onMapPressed), // Add the button here
          ],
        ),
      ),
    );
  }

  Widget _buildViewMapButton(VoidCallback onPressed) {
    return Container(
      margin: EdgeInsets.only(top: 10),
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Color(0xff800000), // Button color
          padding: EdgeInsets.symmetric(vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          elevation: 3,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.map, color: Colors.white),
            SizedBox(width: 8),
            Text(
              "View Map",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }

  void _openGoogleMaps(String coordinates) {
    // Replace with actual implementation to open Google Maps.
    print("Opening Google Maps at: $coordinates");
  }
}